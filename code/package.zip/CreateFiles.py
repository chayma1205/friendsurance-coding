from os import path
import os
import json, boto3, sys, uuid
import requests


def handler(event, context):
    bucket_name = os.environ['bucket_name']
    dynamodb_table = os.environ['dynamodb']
    url = os.environ['url']
    reqponse = requests.get(url)
    filenname = get_filename(url)
    img = reqponse.content
    s3_client = boto3.resource("s3")
    s3_client.Bucket(bucket_name).put_object(Key=filenname, Body=img)
    add_metadata(dynamodb_table, filenname, url)

    return {'statusCode': 200, 'body': json.dumps('file is created in:')}


def get_filename(url):
    fragment_removed = url.split("#")[0]
    query_string_removed = fragment_removed.split("?")[0]
    scheme_removed = query_string_removed.split("://")[-1].split(":")[-1]
    if scheme_removed.find("/") == -1:
        return ""
    return path.basename(scheme_removed)


def add_metadata(dynamodb_table, name, url):
    dynamodb = boto3.client('dynamodb')
    dynamodb.put_item(TableName=dynamodb_table, Item={'Name': {'S': name}, 'OriginalLink': {'N': url}})
    return {'statusCode': 200}

